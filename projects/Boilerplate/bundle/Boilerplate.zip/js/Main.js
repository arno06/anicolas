var Main =
{
    init:function()
    {
        alert("Hello world");
        var d= document.createElement("div");
        d.innerHTML = "Div creation";
        document.body.appendChild(d);
    }
};

window.addEventListener("load", Main.init, false);